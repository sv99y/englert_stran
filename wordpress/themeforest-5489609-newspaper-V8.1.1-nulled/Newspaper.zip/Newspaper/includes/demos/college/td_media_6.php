<?php
//ads
td_demo_media::add_image_to_media_gallery('td_college_header_ad',              "http://demo_content.tagdiv.com/Newspaper_6/college/banner-header.jpg");
td_demo_media::add_image_to_media_gallery('td_college_post_ad',                 "http://demo_content.tagdiv.com/Newspaper_6/college/banner-post.jpg");
td_demo_media::add_image_to_media_gallery('td_college_sidebar_ad',              "http://demo_content.tagdiv.com/Newspaper_6/college/banner-sidebar.jpg");
