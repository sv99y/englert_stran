<?php
//ads
td_demo_media::add_image_to_media_gallery('td_sidebar_ad',             "http://demo_content.tagdiv.com/Newspaper_6/black/rec300.jpg");