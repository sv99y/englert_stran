<?php
td_demo_media::add_image_to_media_gallery('td_pic_4',                   "http://demo_content.tagdiv.com/Newspaper_6/health/4.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_5',                   "http://demo_content.tagdiv.com/Newspaper_6/health/5.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_6',                   "http://demo_content.tagdiv.com/Newspaper_6/health/6.jpg");
