<?php
//ads
td_demo_media::add_image_to_media_gallery('td_politics_post_ad',                 "http://demo_content.tagdiv.com/Newspaper_6/politics/banner-post.jpg");
td_demo_media::add_image_to_media_gallery('td_politics_sidebar_ad',              "http://demo_content.tagdiv.com/Newspaper_6/politics/banner-sidebar.jpg");
